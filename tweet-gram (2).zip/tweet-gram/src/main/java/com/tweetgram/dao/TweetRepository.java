package com.tweetgram.dao;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.tweetgram.model.TweetId;
import com.tweetgram.model.TweetList;

@Repository
public interface TweetRepository extends CassandraRepository<TweetList, TweetId> {

}
