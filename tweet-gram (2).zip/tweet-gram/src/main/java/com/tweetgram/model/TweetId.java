package com.tweetgram.model;

import java.io.Serializable;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@PrimaryKeyClass
@NoArgsConstructor
@Getter
@Setter
public class TweetId implements Serializable {
	@PrimaryKeyColumn(type = PrimaryKeyType.PARTITIONED)
	String email;
	@PrimaryKeyColumn(name = "tweet_text", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
	String tweetText;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTweetText() {
		return tweetText;
	}

	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
}
