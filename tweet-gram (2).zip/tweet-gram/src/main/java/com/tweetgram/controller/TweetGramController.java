package com.tweetgram.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetgram.model.Login;
import com.tweetgram.model.TweetList;
import com.tweetgram.service.LoginService;
import com.tweetgram.service.TweetService;

@RestController
public class TweetGramController {

	@Autowired
	LoginService loginService;
	@Autowired
	TweetService tweetService;

	@GetMapping("/loginUser")
	public boolean loginUser(@RequestBody Login login) {

		if (Objects.nonNull(login) && !login.getEmail().isEmpty() && !login.getPassword().isEmpty()) {
			if (loginService.loginUser(login)) {
				return true;
			}
		}
		return false;

	}

	@PostMapping("/saveUser")
	public boolean saveUser(@RequestBody Login login) throws ParseException {

		if (login != null) {

			return loginService.saveUser(login);
		}
		return false;
	}
	@PutMapping("/updateUser")
	public boolean updateUser(@RequestBody Login login) {
		//System.out.println(login);
		if(login!=null&&login.getEmail()!=null && login.getPassword()!=null) {
			return loginService.updateUser(login);
		}
		return false;
	}

	@GetMapping("/viewAllTweet")
	public List<TweetList> viewAllTweet() {
		return tweetService.viewAllTweet();
	}
	@PostMapping("/postTweet")
	public boolean postTweet(@RequestBody TweetList tweetList) {
		if(tweetList!=null )
			return tweetService.postTweet(tweetList);
		else
			return false;
	
	}
}
